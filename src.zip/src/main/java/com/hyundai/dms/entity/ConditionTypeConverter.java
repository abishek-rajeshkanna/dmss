package com.hyundai.dms.entity;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false)
public class ConditionTypeConverter implements AttributeConverter<Inventory.ConditionType, String> {

    @Override
    public String convertToDatabaseColumn(Inventory.ConditionType attribute) {
        if (attribute == null) return null;
        return switch (attribute) {
            case new_ -> "new";
            case used -> "used";
            case certified_pre_owned -> "certified_pre_owned";
        };
    }

    @Override
    public Inventory.ConditionType convertToEntityAttribute(String dbData) {
        if (dbData == null) return null;
        return switch (dbData) {
            case "new" -> Inventory.ConditionType.new_;
            case "used" -> Inventory.ConditionType.used;
            case "certified_pre_owned" -> Inventory.ConditionType.certified_pre_owned;
            default -> throw new IllegalArgumentException("Unknown condition_type: " + dbData);
        };
    }
}
