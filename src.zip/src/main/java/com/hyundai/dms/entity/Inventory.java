package com.hyundai.dms.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory")
@Getter @Setter @NoArgsConstructor
public class Inventory {

    public enum FuelType { petrol, diesel, electric, hybrid, cng, lpg }
    public enum Transmission { manual, automatic, amt, cvt }
    public enum BodyType { sedan, suv, hatchback, coupe, convertible, wagon, pickup, van, truck, other }
    public enum ConditionType { new_, used, certified_pre_owned }
    public enum Status { available, reserved, sold, in_service, test_drive }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "INT UNSIGNED")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dealership_id", nullable = false)
    private Dealership dealership;

    @Column(nullable = false, length = 17, unique = true)
    private String vin;

    @Column(nullable = false, length = 100)
    private String make;

    @Column(nullable = false, length = 100)
    private String model;

    @Column(length = 100)
    private String variant;

    @Column(nullable = false)
    private Integer year;

    @Column(length = 60)
    private String color;

    @Enumerated(EnumType.STRING)
    @Column(name = "fuel_type", nullable = false, length = 20)
    private FuelType fuelType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Transmission transmission = Transmission.manual;

    @Enumerated(EnumType.STRING)
    @Column(name = "body_type", length = 20)
    private BodyType bodyType;

    @Column(nullable = false)
    private Integer mileage = 0;

    @Column(name = "engine_cc")
    private Integer engineCc;

    @Column
    private Integer seating;

    @Convert(converter = ConditionTypeConverter.class)
    @Column(name = "condition_type", nullable = false, length = 25)
    private ConditionType conditionType = ConditionType.new_;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Status status = Status.available;

    @Column(name = "cost_price", nullable = false, precision = 12, scale = 2)
    private BigDecimal costPrice;

    @Column(name = "selling_price", nullable = false, precision = 12, scale = 2)
    private BigDecimal sellingPrice;

    @Column(precision = 12, scale = 2)
    private BigDecimal msrp;

    @Column(length = 100)
    private String location;

    @Column(columnDefinition = "json")
    private String photos;

    @Column(columnDefinition = "json")
    private String features;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "intake_date", nullable = false)
    private LocalDate intakeDate;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (intakeDate == null) intakeDate = LocalDate.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
