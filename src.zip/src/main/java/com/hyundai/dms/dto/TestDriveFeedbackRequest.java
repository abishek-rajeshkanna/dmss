package com.hyundai.dms.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public record TestDriveFeedbackRequest(
        String feedback,
        @Min(1) @Max(5) Integer rating,
        String notes
) {}
