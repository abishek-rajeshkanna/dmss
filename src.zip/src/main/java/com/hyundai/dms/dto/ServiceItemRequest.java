package com.hyundai.dms.dto;

import com.hyundai.dms.entity.ServiceItem;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public record ServiceItemRequest(
        @NotNull ServiceItem.ItemType itemType,
        String partNumber,
        @NotBlank String description,
        @NotNull @Positive BigDecimal unitCost,
        @NotNull @Positive BigDecimal quantity,
        boolean isWarranty
) {}
