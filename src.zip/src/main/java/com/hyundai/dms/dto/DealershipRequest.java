package com.hyundai.dms.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record DealershipRequest(
        @NotBlank @Size(max = 150) String name,
        @NotBlank String address,
        @NotBlank @Size(max = 100) String city,
        @NotBlank @Size(max = 100) String state,
        @NotBlank @Size(max = 20) String postalCode,
        @NotBlank @Size(max = 80) String country,
        @NotBlank @Size(max = 20) String phone,
        @NotBlank @Email @Size(max = 191) String email,
        @NotBlank @Size(max = 100) String licenseNo,
        String website
) {}
