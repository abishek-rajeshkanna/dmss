package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Inventory;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public record InventoryResponse(
        Long id,
        Long dealershipId,
        String vin,
        String make,
        String model,
        String variant,
        Integer year,
        String color,
        Inventory.FuelType fuelType,
        Inventory.Transmission transmission,
        Inventory.BodyType bodyType,
        Integer mileage,
        Integer engineCc,
        Integer seating,
        Inventory.ConditionType conditionType,
        Inventory.Status status,
        BigDecimal costPrice,
        BigDecimal sellingPrice,
        BigDecimal msrp,
        String location,
        String notes,
        LocalDate intakeDate,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public static InventoryResponse from(Inventory i) {
        return new InventoryResponse(
                i.getId(),
                i.getDealership() != null ? i.getDealership().getId() : null,
                i.getVin(), i.getMake(), i.getModel(), i.getVariant(),
                i.getYear(), i.getColor(), i.getFuelType(), i.getTransmission(),
                i.getBodyType(), i.getMileage(), i.getEngineCc(), i.getSeating(),
                i.getConditionType(), i.getStatus(), i.getCostPrice(), i.getSellingPrice(),
                i.getMsrp(), i.getLocation(), i.getNotes(), i.getIntakeDate(),
                i.getCreatedAt(), i.getUpdatedAt()
        );
    }
}
