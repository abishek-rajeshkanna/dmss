package com.hyundai.dms.dto;

import com.hyundai.dms.entity.TestDrive;

import java.time.LocalDateTime;

public record TestDriveResponse(
        Long id,
        Long dealershipId,
        Long customerId,
        String customerName,
        Long inventoryId,
        String vehicleSummary,
        Long staffId,
        String staffName,
        LocalDateTime scheduledAt,
        LocalDateTime startedAt,
        LocalDateTime returnedAt,
        Integer odometerBefore,
        Integer odometerAfter,
        TestDrive.Status status,
        String feedback,
        Integer rating,
        String notes,
        LocalDateTime createdAt
) {
    public static TestDriveResponse from(TestDrive t) {
        return new TestDriveResponse(
                t.getId(),
                t.getDealership() != null ? t.getDealership().getId() : null,
                t.getCustomer() != null ? t.getCustomer().getId() : null,
                t.getCustomer() != null ? t.getCustomer().getFirstName() + " " + t.getCustomer().getLastName() : null,
                t.getInventory() != null ? t.getInventory().getId() : null,
                t.getInventory() != null ? t.getInventory().getMake() + " " + t.getInventory().getModel() : null,
                t.getStaff() != null ? t.getStaff().getId() : null,
                t.getStaff() != null ? t.getStaff().getFirstName() + " " + t.getStaff().getLastName() : null,
                t.getScheduledAt(), t.getStartedAt(), t.getReturnedAt(),
                t.getOdometerBefore(), t.getOdometerAfter(),
                t.getStatus(), t.getFeedback(), t.getRating(), t.getNotes(), t.getCreatedAt()
        );
    }
}
