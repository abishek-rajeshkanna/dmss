package com.hyundai.dms.dto;

import java.math.BigDecimal;

public record DashboardStatsResponse(
        long inventoryCount,
        long customerCount,
        long pendingOrdersCount,
        long activeServiceTicketsCount,
        BigDecimal todaySales
) {}
