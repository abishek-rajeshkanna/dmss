package com.hyundai.dms.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record CreateOrderRequest(
        @NotNull Long customerId,
        Long managerId,
        LocalDate deliveryDate,
        BigDecimal discountAmount,
        BigDecimal taxRate,
        BigDecimal tradeInValue,
        BigDecimal financingAmount,
        Integer financingTerm,
        BigDecimal interestRate,
        String notes,
        com.hyundai.dms.entity.Order.Status status,
        @NotEmpty @Valid List<OrderItemRequest> items
) {}
