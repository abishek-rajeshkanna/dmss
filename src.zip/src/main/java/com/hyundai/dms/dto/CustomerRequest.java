package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Customer;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record CustomerRequest(
        @NotBlank @Size(max = 100) String firstName,
        @NotBlank @Size(max = 100) String lastName,
        @Size(max = 191) String email,
        @NotBlank @Size(max = 20) String phone,
        @Size(max = 20) String alternatePhone,
        LocalDate dateOfBirth,
        Customer.Gender gender,
        @Size(max = 100) String driversLicense,
        @Size(max = 255) String addressLine1,
        @Size(max = 255) String addressLine2,
        @Size(max = 100) String city,
        @Size(max = 100) String state,
        @Size(max = 20) String postalCode,
        @Size(max = 80) String country,
        @NotNull Customer.Source source,
        Long assignedTo,
        String notes
) {}
