package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Inventory;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public record InventoryRequest(
        @NotBlank @Size(max = 17) String vin,
        @NotBlank @Size(max = 100) String make,
        @NotBlank @Size(max = 100) String model,
        @Size(max = 100) String variant,
        @NotNull @Min(1900) @Max(2100) Integer year,
        @Size(max = 60) String color,
        @NotNull Inventory.FuelType fuelType,
        Inventory.Transmission transmission,
        Inventory.BodyType bodyType,
        Integer mileage,
        Integer engineCc,
        Integer seating,
        @NotNull Inventory.ConditionType conditionType,
        @NotNull @DecimalMin("0.0") BigDecimal costPrice,
        @NotNull @DecimalMin("0.0") BigDecimal sellingPrice,
        BigDecimal msrp,
        @NotNull Inventory.Status status,
        @Size(max = 100) String location,
        String notes
) {}
