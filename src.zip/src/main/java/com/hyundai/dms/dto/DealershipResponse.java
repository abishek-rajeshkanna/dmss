package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Dealership;

import java.time.LocalDateTime;

public record DealershipResponse(
        Long id,
        String name,
        String address,
        String city,
        String state,
        String postalCode,
        String country,
        String phone,
        String email,
        String licenseNo,
        String website,
        boolean isActive,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public static DealershipResponse from(Dealership d) {
        return new DealershipResponse(
                d.getId(), d.getName(), d.getAddress(), d.getCity(), d.getState(),
                d.getPostalCode(), d.getCountry(), d.getPhone(), d.getEmail(),
                d.getLicenseNo(), d.getWebsite(), d.isActive(),
                d.getCreatedAt(), d.getUpdatedAt()
        );
    }
}
