package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Order;
import com.hyundai.dms.entity.OrderItem;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record OrderResponse(
        Long id,
        String orderNumber,
        Long dealershipId,
        String dealershipName,
        Long customerId,
        String customerName,
        Long salespersonId,
        String salespersonName,
        Long managerId,
        String status,
        LocalDate orderDate,
        LocalDate deliveryDate,
        BigDecimal subtotal,
        BigDecimal discountAmount,
        BigDecimal taxRate,
        BigDecimal taxAmount,
        BigDecimal totalAmount,
        BigDecimal tradeInValue,
        BigDecimal financingAmount,
        Integer financingTerm,
        BigDecimal interestRate,
        String notes,
        String cancellationReason,
        List<ItemDto> items,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public record ItemDto(
            Long id,
            Long inventoryId,
            String itemType,
            String description,
            BigDecimal unitPrice,
            int quantity,
            BigDecimal discount,
            BigDecimal lineTotal
    ) {
        public static ItemDto from(OrderItem i) {
            return new ItemDto(i.getId(),
                    i.getInventory() != null ? i.getInventory().getId() : null,
                    i.getItemType().name(),
                    i.getDescription(),
                    i.getUnitPrice(),
                    i.getQuantity(),
                    i.getDiscount(),
                    i.getLineTotal());
        }
    }

    public static OrderResponse from(Order o) {
        return new OrderResponse(
                o.getId(),
                o.getOrderNumber(),
                o.getDealership().getId(),
                o.getDealership().getName(),
                o.getCustomer().getId(),
                o.getCustomer().getFirstName() + " " + o.getCustomer().getLastName(),
                o.getSalesperson().getId(),
                o.getSalesperson().getFirstName() + " " + o.getSalesperson().getLastName(),
                o.getManager() != null ? o.getManager().getId() : null,
                o.getStatus().name(),
                o.getOrderDate(),
                o.getDeliveryDate(),
                o.getSubtotal(),
                o.getDiscountAmount(),
                o.getTaxRate(),
                o.getTaxAmount(),
                o.getTotalAmount(),
                o.getTradeInValue(),
                o.getFinancingAmount(),
                o.getFinancingTerm(),
                o.getInterestRate(),
                o.getNotes(),
                o.getCancellationReason(),
                o.getItems().stream().map(ItemDto::from).toList(),
                o.getCreatedAt(),
                o.getUpdatedAt()
        );
    }
}
