package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Payment;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record PaymentRequest(
        @NotNull Long orderId,
        @NotNull @Positive BigDecimal amount,
        @NotNull Payment.Method method,
        Payment.Status status,
        String transactionRef,
        String gateway,
        LocalDateTime paidAt,
        String notes
) {}
