package com.hyundai.dms.dto;

import com.hyundai.dms.entity.OrderItem;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public record OrderItemRequest(
        Long inventoryId,
        @NotNull OrderItem.ItemType itemType,
        @NotBlank String description,
        @NotNull @Positive BigDecimal unitPrice,
        @Min(1) int quantity,
        BigDecimal discount
) {}
