package com.hyundai.dms.dto;

import jakarta.validation.constraints.NotBlank;

public record StatusRequest(@NotBlank String status, String reason) {}
