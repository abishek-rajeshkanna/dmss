package com.hyundai.dms.dto;

import com.hyundai.dms.entity.ServiceItem;
import com.hyundai.dms.entity.ServiceTicket;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record ServiceTicketResponse(
        Long id,
        String ticketNumber,
        Long dealershipId,
        Long customerId,
        String customerName,
        Long inventoryId,
        String vehicleVin,
        Long assignedToId,
        String assignedToName,
        String serviceType,
        String priority,
        String status,
        String complaint,
        String diagnosis,
        LocalDateTime dropOffAt,
        LocalDateTime promisedAt,
        LocalDateTime completedAt,
        LocalDateTime deliveredAt,
        Integer odometerIn,
        Integer odometerOut,
        BigDecimal totalParts,
        BigDecimal totalLabor,
        BigDecimal totalCost,
        boolean customerApproval,
        String notes,
        List<ItemDto> items,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public record ItemDto(
            Long id,
            String itemType,
            String partNumber,
            String description,
            BigDecimal unitCost,
            BigDecimal quantity,
            BigDecimal lineTotal,
            boolean isWarranty
    ) {
        public static ItemDto from(ServiceItem i) {
            return new ItemDto(i.getId(), i.getItemType().name(), i.getPartNumber(),
                    i.getDescription(), i.getUnitCost(), i.getQuantity(),
                    i.getLineTotal(), i.isWarranty());
        }
    }

    public static ServiceTicketResponse from(ServiceTicket t) {
        return new ServiceTicketResponse(
                t.getId(),
                t.getTicketNumber(),
                t.getDealership().getId(),
                t.getCustomer().getId(),
                t.getCustomer().getFirstName() + " " + t.getCustomer().getLastName(),
                t.getInventory().getId(),
                t.getInventory().getVin(),
                t.getAssignedTo() != null ? t.getAssignedTo().getId() : null,
                t.getAssignedTo() != null
                        ? t.getAssignedTo().getFirstName() + " " + t.getAssignedTo().getLastName() : null,
                t.getServiceType().name(),
                t.getPriority().name(),
                t.getStatus().name(),
                t.getComplaint(),
                t.getDiagnosis(),
                t.getDropOffAt(),
                t.getPromisedAt(),
                t.getCompletedAt(),
                t.getDeliveredAt(),
                t.getOdometerIn(),
                t.getOdometerOut(),
                t.getTotalParts(),
                t.getTotalLabor(),
                t.getTotalCost(),
                t.isCustomerApproval(),
                t.getNotes(),
                t.getItems().stream().map(ItemDto::from).toList(),
                t.getCreatedAt(),
                t.getUpdatedAt()
        );
    }
}
