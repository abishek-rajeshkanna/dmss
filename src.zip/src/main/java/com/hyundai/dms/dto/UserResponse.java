package com.hyundai.dms.dto;

import com.hyundai.dms.entity.User;

import java.time.LocalDateTime;

public record UserResponse(
        Long id,
        Long dealershipId,
        String dealershipName,
        Long managerId,
        String firstName,
        String lastName,
        String email,
        User.Role role,
        String phone,
        User.Status status,
        LocalDateTime lastLogin,
        LocalDateTime createdAt
) {
    public static UserResponse from(User u) {
        return new UserResponse(
                u.getId(),
                u.getDealership() != null ? u.getDealership().getId() : null,
                u.getDealership() != null ? u.getDealership().getName() : null,
                u.getManager() != null ? u.getManager().getId() : null,
                u.getFirstName(),
                u.getLastName(),
                u.getEmail(),
                u.getRole(),
                u.getPhone(),
                u.getStatus(),
                u.getLastLogin(),
                u.getCreatedAt()
        );
    }
}
