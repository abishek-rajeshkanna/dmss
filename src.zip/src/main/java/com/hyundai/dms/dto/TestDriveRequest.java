package com.hyundai.dms.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public record TestDriveRequest(
        @NotNull Long customerId,
        @NotNull Long inventoryId,
        @NotNull Long staffId,
        @NotNull LocalDateTime scheduledAt,
        @NotNull com.hyundai.dms.entity.TestDrive.Status status,
        Integer odometerBefore,
        String notes
) {}
