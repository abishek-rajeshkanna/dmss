package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Payment;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record PaymentResponse(
        Long id,
        Long orderId,
        String orderNumber,
        Long recordedById,
        BigDecimal amount,
        String method,
        String status,
        String transactionRef,
        String gateway,
        LocalDateTime paidAt,
        String notes,
        LocalDateTime createdAt
) {
    public static PaymentResponse from(Payment p) {
        return new PaymentResponse(
                p.getId(),
                p.getOrder().getId(),
                p.getOrder().getOrderNumber(),
                p.getRecordedBy() != null ? p.getRecordedBy().getId() : null,
                p.getAmount(),
                p.getMethod().name(),
                p.getStatus().name(),
                p.getTransactionRef(),
                p.getGateway(),
                p.getPaidAt(),
                p.getNotes(),
                p.getCreatedAt()
        );
    }
}
