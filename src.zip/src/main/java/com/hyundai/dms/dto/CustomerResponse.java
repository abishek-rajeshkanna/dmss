package com.hyundai.dms.dto;

import com.hyundai.dms.entity.Customer;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record CustomerResponse(
        Long id,
        Long dealershipId,
        Long assignedTo,
        String firstName,
        String lastName,
        String email,
        String phone,
        String alternatePhone,
        LocalDate dateOfBirth,
        Customer.Gender gender,
        String driversLicense,
        String addressLine1,
        String city,
        String state,
        String postalCode,
        String country,
        Customer.Source source,
        Customer.Status status,
        String notes,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public static CustomerResponse from(Customer c) {
        return new CustomerResponse(
                c.getId(),
                c.getDealership() != null ? c.getDealership().getId() : null,
                c.getAssignedTo() != null ? c.getAssignedTo().getId() : null,
                c.getFirstName(), c.getLastName(), c.getEmail(), c.getPhone(),
                c.getAlternatePhone(), c.getDateOfBirth(), c.getGender(),
                c.getDriversLicense(), c.getAddressLine1(), c.getCity(),
                c.getState(), c.getPostalCode(), c.getCountry(),
                c.getSource(), c.getStatus(), c.getNotes(),
                c.getCreatedAt(), c.getUpdatedAt()
        );
    }
}
