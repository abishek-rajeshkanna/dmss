package com.hyundai.dms.dto;

import com.hyundai.dms.entity.ServiceTicket;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public record ServiceTicketRequest(
        @NotNull Long customerId,
        @NotNull Long inventoryId,
        Long assignedTo,
        @NotNull ServiceTicket.ServiceType serviceType,
        ServiceTicket.Priority priority,
        @NotBlank String complaint,
        @NotNull ServiceTicket.Status status,
        LocalDateTime promisedAt,
        Integer odometerIn,
        String notes
) {}
