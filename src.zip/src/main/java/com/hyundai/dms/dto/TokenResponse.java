package com.hyundai.dms.dto;

public record TokenResponse(
        String accessToken,
        String refreshToken,
        long expiresIn
) {}
