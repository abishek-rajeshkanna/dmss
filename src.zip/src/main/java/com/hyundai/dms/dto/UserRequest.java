package com.hyundai.dms.dto;

import com.hyundai.dms.entity.User;
import jakarta.validation.constraints.*;

public record UserRequest(
        @NotNull Long dealershipId,
        Long managerId,
        @NotBlank @Size(max = 100) String firstName,
        @NotBlank @Size(max = 100) String lastName,
        @NotBlank @Email @Size(max = 191) String email,
        @NotBlank @Size(min = 8, max = 100) String password,
        @NotNull User.Role role,
        @Size(max = 20) String phone
) {}
