package com.hyundai.dms.exception;

public class AccountInactiveException extends RuntimeException {
    public AccountInactiveException() {
        super("Account is inactive or suspended");
    }
    public AccountInactiveException(String message) {
        super(message);
    }
}
