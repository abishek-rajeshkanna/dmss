package com.hyundai.dms.exception;

public class OrderAlreadyPaidException extends RuntimeException {
    public OrderAlreadyPaidException() {
        super("Order is already fully paid");
    }
    public OrderAlreadyPaidException(String message) {
        super(message);
    }
}
