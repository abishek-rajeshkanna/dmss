package com.hyundai.dms.repository;

import com.hyundai.dms.entity.ServiceItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ServiceItemRepository extends JpaRepository<ServiceItem, Long> {
    List<ServiceItem> findByTicketId(Long ticketId);
}
