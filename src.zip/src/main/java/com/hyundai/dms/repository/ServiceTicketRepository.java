package com.hyundai.dms.repository;

import com.hyundai.dms.entity.ServiceTicket;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ServiceTicketRepository extends JpaRepository<ServiceTicket, Long> {

    @Query("""
        SELECT t FROM ServiceTicket t
        WHERE (:dealershipId IS NULL OR t.dealership.id = :dealershipId)
          AND (:status IS NULL OR t.status = :status)
          AND (:priority IS NULL OR t.priority = :priority)
          AND (:assignedTo IS NULL OR t.assignedTo.id = :assignedTo)
          AND (:customerId IS NULL OR t.customer.id = :customerId)
        """)
    Page<ServiceTicket> findByFilters(@Param("dealershipId") Long dealershipId,
                                      @Param("status") ServiceTicket.Status status,
                                      @Param("priority") ServiceTicket.Priority priority,
                                      @Param("assignedTo") Long assignedTo,
                                      @Param("customerId") Long customerId,
                                      Pageable pageable);

    long countByStatusIn(java.util.Collection<com.hyundai.dms.entity.ServiceTicket.Status> statuses);
    long countByDealershipIdAndStatusIn(Long dealershipId, java.util.Collection<com.hyundai.dms.entity.ServiceTicket.Status> statuses);

    boolean existsByTicketNumber(String ticketNumber);
}
