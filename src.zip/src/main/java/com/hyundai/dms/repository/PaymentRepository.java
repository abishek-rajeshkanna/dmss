package com.hyundai.dms.repository;

import com.hyundai.dms.entity.Payment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    Page<Payment> findByOrderId(Long orderId, Pageable pageable);

    Page<Payment> findByStatus(Payment.Status status, Pageable pageable);

    @Query("SELECT COALESCE(SUM(p.amount), 0) FROM Payment p WHERE p.order.id = :orderId AND p.status = 'completed'")
    BigDecimal sumCompletedByOrderId(@Param("orderId") Long orderId);
}
