package com.hyundai.dms.repository;

import com.hyundai.dms.entity.Inventory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {

    boolean existsByVin(String vin);
    boolean existsByVinAndIdNot(String vin, Long id);

    @Query("SELECT i FROM Inventory i WHERE i.dealership.id = :dealershipId " +
           "AND (:status IS NULL OR i.status = :status) " +
           "AND (:make IS NULL OR LOWER(i.make) LIKE LOWER(CONCAT('%',:make,'%'))) " +
           "AND (:model IS NULL OR LOWER(i.model) LIKE LOWER(CONCAT('%',:model,'%'))) " +
           "AND (:conditionType IS NULL OR i.conditionType = :conditionType) " +
           "AND (:fuelType IS NULL OR i.fuelType = :fuelType) " +
           "AND (:minPrice IS NULL OR i.sellingPrice >= :minPrice) " +
           "AND (:maxPrice IS NULL OR i.sellingPrice <= :maxPrice)")
    Page<Inventory> findByFilters(@Param("dealershipId") Long dealershipId,
                                  @Param("status") Inventory.Status status,
                                  @Param("make") String make,
                                  @Param("model") String model,
                                  @Param("conditionType") Inventory.ConditionType conditionType,
                                  @Param("fuelType") Inventory.FuelType fuelType,
                                  @Param("minPrice") BigDecimal minPrice,
                                  @Param("maxPrice") java.math.BigDecimal maxPrice,
                                  Pageable pageable);

    long countByDealershipId(Long dealershipId);
}
