package com.hyundai.dms.repository;

import com.hyundai.dms.entity.Dealership;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DealershipRepository extends JpaRepository<Dealership, Long> {
    boolean existsByEmail(String email);
    boolean existsByLicenseNo(String licenseNo);
    boolean existsByEmailAndIdNot(String email, Long id);
    boolean existsByLicenseNoAndIdNot(String licenseNo, Long id);
    Optional<Dealership> findByIdAndIsActiveTrue(Long id);
}
