package com.hyundai.dms.repository;

import com.hyundai.dms.entity.Customer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    @Query("SELECT c FROM Customer c WHERE c.dealership.id = :dealershipId " +
           "AND (:status IS NULL OR c.status = :status) " +
           "AND (:assignedTo IS NULL OR c.assignedTo.id = :assignedTo)")
    Page<Customer> findByFilters(@Param("dealershipId") Long dealershipId,
                                 @Param("status") Customer.Status status,
                                 @Param("assignedTo") Long assignedTo,
                                 Pageable pageable);

    long countByDealershipId(Long dealershipId);
}
