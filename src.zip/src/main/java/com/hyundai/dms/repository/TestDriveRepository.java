package com.hyundai.dms.repository;

import com.hyundai.dms.entity.TestDrive;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TestDriveRepository extends JpaRepository<TestDrive, Long> {

    @Query("SELECT t FROM TestDrive t WHERE t.dealership.id = :dealershipId " +
           "AND (:status IS NULL OR t.status = :status) " +
           "AND (:customerId IS NULL OR t.customer.id = :customerId) " +
           "AND (:inventoryId IS NULL OR t.inventory.id = :inventoryId)")
    Page<TestDrive> findByFilters(@Param("dealershipId") Long dealershipId,
                                  @Param("status") TestDrive.Status status,
                                  @Param("customerId") Long customerId,
                                  @Param("inventoryId") Long inventoryId,
                                  Pageable pageable);
}
