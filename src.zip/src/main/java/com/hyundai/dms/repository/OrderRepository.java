package com.hyundai.dms.repository;

import com.hyundai.dms.entity.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;

public interface OrderRepository extends JpaRepository<Order, Long> {

    @Query("""
        SELECT o FROM Order o
        WHERE (:dealershipId IS NULL OR o.dealership.id = :dealershipId)
          AND (:status IS NULL OR o.status = :status)
          AND (:customerId IS NULL OR o.customer.id = :customerId)
          AND (:fromDate IS NULL OR o.orderDate >= :fromDate)
          AND (:toDate IS NULL OR o.orderDate <= :toDate)
        """)
    Page<Order> findByFilters(@Param("dealershipId") Long dealershipId,
                              @Param("status") Order.Status status,
                              @Param("customerId") Long customerId,
                              @Param("fromDate") LocalDate fromDate,
                              @Param("toDate") LocalDate toDate,
                              Pageable pageable);

    boolean existsByOrderNumber(String orderNumber);

    long countByStatus(Order.Status status);
    long countByDealershipIdAndStatus(Long dealershipId, Order.Status status);

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.createdAt >= :start AND o.createdAt <= :end")
    java.math.BigDecimal sumTotalAmountByOrderDateBetween(@Param("start") java.time.LocalDateTime start, @Param("end") java.time.LocalDateTime end);

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.dealership.id = :dealershipId AND o.createdAt >= :start AND o.createdAt <= :end")
    java.math.BigDecimal sumTotalAmountByDealershipIdAndOrderDateBetween(@Param("dealershipId") Long dealershipId, @Param("start") java.time.LocalDateTime start, @Param("end") java.time.LocalDateTime end);
}
