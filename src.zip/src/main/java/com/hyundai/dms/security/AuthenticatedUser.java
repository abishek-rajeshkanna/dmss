package com.hyundai.dms.security;

import com.hyundai.dms.entity.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class AuthenticatedUser implements UserDetails {

    private final Long userId;
    private final String email;
    private final String passwordHash;
    private final String roleName;
    private final Long dealershipId;
    private final boolean enabled;

    /** Used by UserDetailsServiceImpl (loads from DB) */
    public AuthenticatedUser(User user) {
        this.userId = user.getId();
        this.email = user.getEmail();
        this.passwordHash = user.getPasswordHash();
        this.roleName = user.getRole().name();
        this.dealershipId = user.getDealership() != null ? user.getDealership().getId() : null;
        this.enabled = user.getStatus() == User.Status.active;
    }

    /** Used by JwtAuthenticationFilter (built from JWT claims) */
    public AuthenticatedUser(Long userId, String roleName, Long dealershipId) {
        this.userId = userId;
        this.email = null;
        this.passwordHash = null;
        this.roleName = roleName;
        this.dealershipId = dealershipId;
        this.enabled = true;
    }

    public Long getUserId() { return userId; }
    public String getRoleName() { return roleName; }
    public Long getDealershipId() { return dealershipId; }
    public boolean isSuperAdmin() { return "super_admin".equals(roleName); }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + roleName.toUpperCase()));
    }

    @Override public String getPassword() { return passwordHash; }
    @Override public String getUsername() { return email; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return enabled; }
}
