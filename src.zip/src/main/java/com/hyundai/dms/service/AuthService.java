package com.hyundai.dms.service;

import com.hyundai.dms.dto.LoginRequest;
import com.hyundai.dms.dto.TokenResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.entity.RefreshToken;
import com.hyundai.dms.entity.User;
import com.hyundai.dms.exception.AccountInactiveException;
import com.hyundai.dms.exception.AccountLockedException;
import com.hyundai.dms.exception.InvalidTokenException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.RefreshTokenRepository;
import com.hyundai.dms.repository.UserRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthService {

    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final int LOCK_DURATION_MINUTES = 15;

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    @Value("${app.jwt.refresh-token-expiry-days}")
    private int refreshTokenExpiryDays;

    @Transactional
    public TokenResponse login(LoginRequest request, String ipAddress, String userAgent) {
        User user = userRepository.findByEmail(request.email())
                .orElseThrow(() -> new ResourceNotFoundException("Invalid credentials"));

        // Check account status
        if (user.getStatus() != User.Status.active) {
            throw new AccountInactiveException("Account is " + user.getStatus().name());
        }

        // Check lockout
        if (user.getLockedUntil() != null && LocalDateTime.now().isBefore(user.getLockedUntil())) {
            throw new AccountLockedException(user.getLockedUntil());
        }

        // Verify password
        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            int attempts = user.getFailedLoginAttempts() + 1;
            user.setFailedLoginAttempts(attempts);
            if (attempts >= MAX_FAILED_ATTEMPTS) {
                user.setLockedUntil(LocalDateTime.now().plusMinutes(LOCK_DURATION_MINUTES));
            }
            userRepository.save(user);
            auditService.log(user.getId(), user.getDealership().getId(),
                    AuditLog.Action.LOGIN_FAILED, "users", user.getId(),
                    null, null, ipAddress, userAgent);
            throw new ResourceNotFoundException("Invalid credentials");
        }

        // Success — reset state
        user.setFailedLoginAttempts(0);
        user.setLockedUntil(null);
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        AuthenticatedUser principal = new AuthenticatedUser(user);
        String accessToken = jwtUtil.generateAccessToken(principal);
        String rawRefresh = jwtUtil.generateRefreshToken();
        String hashRefresh = jwtUtil.hashToken(rawRefresh);

        RefreshToken rt = new RefreshToken();
        rt.setUser(user);
        rt.setTokenHash(hashRefresh);
        rt.setExpiresAt(LocalDateTime.now().plusDays(refreshTokenExpiryDays));
        rt.setIpAddress(ipAddress);
        rt.setUserAgent(userAgent);
        refreshTokenRepository.save(rt);

        auditService.log(user.getId(), user.getDealership().getId(),
                AuditLog.Action.LOGIN, "users", user.getId(),
                null, null, ipAddress, userAgent);

        return new TokenResponse(accessToken, rawRefresh, 900L);
    }

    @Transactional
    public TokenResponse refresh(String rawRefreshToken, String ipAddress, String userAgent) {
        String hash = jwtUtil.hashToken(rawRefreshToken);
        RefreshToken rt = refreshTokenRepository.findByTokenHash(hash)
                .orElseThrow(() -> new InvalidTokenException("Invalid refresh token"));

        if (rt.isRevoked()) throw new InvalidTokenException("Refresh token has been revoked");
        if (LocalDateTime.now().isAfter(rt.getExpiresAt())) throw new InvalidTokenException("Refresh token has expired");

        // Revoke old token
        rt.setRevoked(true);
        rt.setRevokedAt(LocalDateTime.now());
        refreshTokenRepository.save(rt);

        User user = rt.getUser();
        AuthenticatedUser principal = new AuthenticatedUser(user);
        String newAccess = jwtUtil.generateAccessToken(principal);
        String newRawRefresh = jwtUtil.generateRefreshToken();
        String newHash = jwtUtil.hashToken(newRawRefresh);

        RefreshToken newRt = new RefreshToken();
        newRt.setUser(user);
        newRt.setTokenHash(newHash);
        newRt.setExpiresAt(LocalDateTime.now().plusDays(refreshTokenExpiryDays));
        newRt.setIpAddress(ipAddress);
        newRt.setUserAgent(userAgent);
        refreshTokenRepository.save(newRt);

        return new TokenResponse(newAccess, newRawRefresh, 900L);
    }

    @Transactional
    public void logout(Long userId, Long dealershipId, String ipAddress, String userAgent) {
        refreshTokenRepository.revokeAllByUserId(userId, LocalDateTime.now());
        auditService.log(userId, dealershipId, AuditLog.Action.LOGOUT,
                "users", userId, null, null, ipAddress, userAgent);
    }
}
