package com.hyundai.dms.service;

import com.hyundai.dms.dto.CustomerRequest;
import com.hyundai.dms.dto.CustomerResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.entity.Customer;
import com.hyundai.dms.entity.Dealership;
import com.hyundai.dms.entity.User;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.CustomerRepository;
import com.hyundai.dms.repository.DealershipRepository;
import com.hyundai.dms.repository.UserRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final DealershipRepository dealershipRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public Page<CustomerResponse> findAll(Customer.Status status, Long assignedTo,
                                          AuthenticatedUser actor, Pageable pageable) {
        Long dealershipId = actor.isSuperAdmin() ? null : actor.getDealershipId();
        if (dealershipId == null) {
            // super_admin: no scoping — use a broad query
            return customerRepository.findAll(pageable).map(CustomerResponse::from);
        }
        return customerRepository.findByFilters(dealershipId, status, assignedTo, pageable)
                .map(CustomerResponse::from);
    }

    @Transactional(readOnly = true)
    public CustomerResponse findById(Long id, AuthenticatedUser actor) {
        Customer c = getCustomer(id, actor);
        return CustomerResponse.from(c);
    }

    @Transactional
    public CustomerResponse create(CustomerRequest req, AuthenticatedUser actor) {
        Long dealershipId = actor.isSuperAdmin() ? req.assignedTo() : actor.getDealershipId();
        Dealership dealership = dealershipRepository.findById(actor.getDealershipId() != null
                        ? actor.getDealershipId() : dealershipId)
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        Customer c = new Customer();
        c.setDealership(dealership);
        mapToEntity(c, req);
        c = customerRepository.save(c);

        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.INSERT, "customers", c.getId(), null, null, null, null);
        return CustomerResponse.from(c);
    }

    @Transactional
    public CustomerResponse update(Long id, CustomerRequest req, AuthenticatedUser actor) {
        Customer c = getCustomer(id, actor);
        mapToEntity(c, req);
        c = customerRepository.save(c);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "customers", c.getId(), null, null, null, null);
        return CustomerResponse.from(c);
    }

    @Transactional
    public void changeStatus(Long id, String status, AuthenticatedUser actor) {
        Customer c = getCustomer(id, actor);
        c.setStatus(Customer.Status.valueOf(status));
        customerRepository.save(c);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "customers", c.getId(), null, null, null, null);
    }

    @Transactional
    public void softDelete(Long id, AuthenticatedUser actor) {
        Customer c = getCustomer(id, actor);
        c.setStatus(Customer.Status.lost);
        customerRepository.save(c);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.DELETE, "customers", c.getId(), null, null, null, null);
    }

    private Customer getCustomer(Long id, AuthenticatedUser actor) {
        Customer c = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + id));
        if (!actor.isSuperAdmin() && !c.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
        return c;
    }

    private void mapToEntity(Customer c, CustomerRequest req) {
        c.setFirstName(req.firstName());
        c.setLastName(req.lastName());
        c.setEmail(req.email());
        c.setPhone(req.phone());
        c.setAlternatePhone(req.alternatePhone());
        c.setDateOfBirth(req.dateOfBirth());
        c.setGender(req.gender());
        c.setDriversLicense(req.driversLicense());
        c.setAddressLine1(req.addressLine1());
        c.setCity(req.city());
        c.setState(req.state());
        c.setPostalCode(req.postalCode());
        c.setCountry(req.country());
        c.setSource(req.source());
        c.setNotes(req.notes());
        if (req.assignedTo() != null) {
            User staff = userRepository.findById(req.assignedTo()).orElse(null);
            c.setAssignedTo(staff);
        }
    }
}
