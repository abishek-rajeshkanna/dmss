package com.hyundai.dms.service;

import com.hyundai.dms.dto.DealershipRequest;
import com.hyundai.dms.dto.DealershipResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.entity.Dealership;
import com.hyundai.dms.exception.DuplicateResourceException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.DealershipRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class DealershipService {

    private final DealershipRepository dealershipRepository;
    private final AuditService auditService;

    @Cacheable("dealerships")
    @Transactional(readOnly = true)
    public Page<DealershipResponse> findAll(Pageable pageable) {
        return dealershipRepository.findAll(pageable).map(DealershipResponse::from);
    }

    @Cacheable(value = "dealership", key = "#id")
    @Transactional(readOnly = true)
    public DealershipResponse findById(Long id) {
        return dealershipRepository.findById(id)
                .map(DealershipResponse::from)
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found: " + id));
    }

    @Caching(evict = {
            @CacheEvict(value = "dealerships", allEntries = true),
            @CacheEvict(value = "dealership", allEntries = true)
    })
    @Transactional
    public DealershipResponse create(DealershipRequest req, AuthenticatedUser actor) {
        if (dealershipRepository.existsByEmail(req.email()))
            throw new DuplicateResourceException("Email already in use");
        if (dealershipRepository.existsByLicenseNo(req.licenseNo()))
            throw new DuplicateResourceException("License number already in use");

        Dealership d = mapToEntity(new Dealership(), req);
        d = dealershipRepository.save(d);
        auditService.log(actor.getUserId(), d.getId(), AuditLog.Action.INSERT,
                "dealerships", d.getId(), null, null, null, null);
        return DealershipResponse.from(d);
    }

    @Caching(evict = {
            @CacheEvict(value = "dealerships", allEntries = true),
            @CacheEvict(value = "dealership", key = "#id")
    })
    @Transactional
    public DealershipResponse update(Long id, DealershipRequest req, AuthenticatedUser actor) {
        Dealership d = dealershipRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found: " + id));

        if (dealershipRepository.existsByEmailAndIdNot(req.email(), id))
            throw new DuplicateResourceException("Email already in use");
        if (dealershipRepository.existsByLicenseNoAndIdNot(req.licenseNo(), id))
            throw new DuplicateResourceException("License number already in use");

        mapToEntity(d, req);
        d = dealershipRepository.save(d);
        auditService.log(actor.getUserId(), d.getId(), AuditLog.Action.UPDATE,
                "dealerships", d.getId(), null, null, null, null);
        return DealershipResponse.from(d);
    }

    @Caching(evict = {
            @CacheEvict(value = "dealerships", allEntries = true),
            @CacheEvict(value = "dealership", key = "#id")
    })
    @Transactional
    public void softDelete(Long id, AuthenticatedUser actor) {
        Dealership d = dealershipRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found: " + id));
        d.setActive(false);
        dealershipRepository.save(d);
        auditService.log(actor.getUserId(), d.getId(), AuditLog.Action.DELETE,
                "dealerships", d.getId(), null, null, null, null);
    }

    private Dealership mapToEntity(Dealership d, DealershipRequest req) {
        d.setName(req.name());
        d.setAddress(req.address());
        d.setCity(req.city());
        d.setState(req.state());
        d.setPostalCode(req.postalCode());
        d.setCountry(req.country());
        d.setPhone(req.phone());
        d.setEmail(req.email());
        d.setLicenseNo(req.licenseNo());
        d.setWebsite(req.website());
        return d;
    }
}
