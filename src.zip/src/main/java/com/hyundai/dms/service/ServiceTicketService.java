package com.hyundai.dms.service;

import com.hyundai.dms.dto.ServiceItemRequest;
import com.hyundai.dms.dto.ServiceTicketRequest;
import com.hyundai.dms.dto.ServiceTicketResponse;
import com.hyundai.dms.entity.*;
import com.hyundai.dms.exception.BusinessRuleException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.*;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
public class ServiceTicketService {

    private final ServiceTicketRepository ticketRepository;
    private final ServiceItemRepository itemRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final InventoryService inventoryService;
    private final AuditService auditService;
    private final NotificationService notificationService;

    @Transactional(readOnly = true)
    public Page<ServiceTicketResponse> findAll(ServiceTicket.Status status,
                                               ServiceTicket.Priority priority,
                                               Long assignedTo, Long customerId,
                                               AuthenticatedUser actor, Pageable pageable) {
        Long dealershipId = actor.isSuperAdmin() ? null : actor.getDealershipId();
        return ticketRepository.findByFilters(dealershipId, status, priority, assignedTo, customerId, pageable)
                .map(ServiceTicketResponse::from);
    }

    @Transactional(readOnly = true)
    public ServiceTicketResponse findById(Long id, AuthenticatedUser actor) {
        return ServiceTicketResponse.from(getTicket(id, actor));
    }

    @Transactional
    public ServiceTicketResponse create(ServiceTicketRequest req, AuthenticatedUser actor) {
        Dealership dealership = dealershipRepository.findById(actor.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));
        Customer customer = customerRepository.findById(req.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
        Inventory inventory = inventoryService.getInventoryById(req.inventoryId());
        User createdBy = userRepository.findById(actor.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        ServiceTicket ticket = new ServiceTicket();
        ticket.setDealership(dealership);
        ticket.setTicketNumber(generateTicketNumber());
        ticket.setCustomer(customer);
        ticket.setInventory(inventory);
        ticket.setCreatedBy(createdBy);
        ticket.setServiceType(req.serviceType());
        ticket.setPriority(req.priority() != null ? req.priority() : ServiceTicket.Priority.medium);
        ticket.setComplaint(req.complaint());
        ticket.setPromisedAt(req.promisedAt());
        ticket.setOdometerIn(req.odometerIn());
        ticket.setNotes(req.notes());

        if (req.assignedTo() != null) {
            User tech = userRepository.findById(req.assignedTo())
                    .orElseThrow(() -> new ResourceNotFoundException("Technician not found"));
            ticket.setAssignedTo(tech);
            notificationService.createForUser(tech.getId(), "TICKET_ASSIGNED",
                    "Service Ticket Assigned",
                    "You have been assigned ticket " + ticket.getTicketNumber(),
                    "service_tickets", null);
        }

        ticket = ticketRepository.save(ticket);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.INSERT, "service_tickets", ticket.getId(), null, null, null, null);
        return ServiceTicketResponse.from(ticket);
    }

    @Transactional
    public ServiceTicketResponse update(Long id, ServiceTicketRequest req, AuthenticatedUser actor) {
        ServiceTicket ticket = getTicket(id, actor);
        Customer customer = customerRepository.findById(req.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
        Inventory inventory = inventoryService.getInventoryById(req.inventoryId());

        ticket.setCustomer(customer);
        ticket.setInventory(inventory);
        ticket.setServiceType(req.serviceType());
        ticket.setPriority(req.priority() != null ? req.priority() : ServiceTicket.Priority.medium);
        ticket.setStatus(req.status());
        ticket.setComplaint(req.complaint());
        ticket.setPromisedAt(req.promisedAt());
        ticket.setOdometerIn(req.odometerIn());
        ticket.setNotes(req.notes());

        if (req.status() == ServiceTicket.Status.completed && ticket.getCompletedAt() == null) {
            ticket.setCompletedAt(LocalDateTime.now());
        } else if (req.status() == ServiceTicket.Status.delivered && ticket.getDeliveredAt() == null) {
            ticket.setDeliveredAt(LocalDateTime.now());
        }

        if (req.assignedTo() != null) {
            User tech = userRepository.findById(req.assignedTo())
                    .orElseThrow(() -> new ResourceNotFoundException("Technician not found"));
            boolean reassigned = ticket.getAssignedTo() == null
                    || !ticket.getAssignedTo().getId().equals(req.assignedTo());
            ticket.setAssignedTo(tech);
            if (reassigned) {
                notificationService.createForUser(tech.getId(), "TICKET_ASSIGNED",
                        "Service Ticket Assigned",
                        "You have been assigned ticket " + ticket.getTicketNumber(),
                        "service_tickets", ticket.getId());
            }
        }

        ticket = ticketRepository.save(ticket);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "service_tickets", ticket.getId(), null, null, null, null);
        return ServiceTicketResponse.from(ticket);
    }

    @Transactional
    public ServiceTicketResponse changeStatus(Long id, ServiceTicket.Status newStatus,
                                              String diagnosis, Integer odometerOut,
                                              AuthenticatedUser actor) {
        ServiceTicket ticket = getTicket(id, actor);
        validateTransition(ticket.getStatus(), newStatus);

        ticket.setStatus(newStatus);
        if (diagnosis != null) ticket.setDiagnosis(diagnosis);
        if (odometerOut != null) ticket.setOdometerOut(odometerOut);

        if (newStatus == ServiceTicket.Status.completed) {
            ticket.setCompletedAt(LocalDateTime.now());
        } else if (newStatus == ServiceTicket.Status.delivered) {
            ticket.setDeliveredAt(LocalDateTime.now());
        }

        ticket = ticketRepository.save(ticket);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "service_tickets", ticket.getId(), null, null, null, null);
        return ServiceTicketResponse.from(ticket);
    }

    @Transactional
    public ServiceTicketResponse addItem(Long ticketId, ServiceItemRequest req, AuthenticatedUser actor) {
        ServiceTicket ticket = getTicket(ticketId, actor);

        ServiceItem item = new ServiceItem();
        item.setTicket(ticket);
        item.setItemType(req.itemType());
        item.setPartNumber(req.partNumber());
        item.setDescription(req.description());
        item.setUnitCost(req.unitCost());
        item.setQuantity(req.quantity());
        item.setWarranty(req.isWarranty());
        item.setLineTotal(req.unitCost().multiply(req.quantity()));
        itemRepository.save(item);

        ticket.getItems().add(item);
        recomputeCosts(ticket);
        ticket = ticketRepository.save(ticket);
        return ServiceTicketResponse.from(ticket);
    }

    // Package-visible for unit tests
    void recomputeCosts(ServiceTicket ticket) {
        BigDecimal parts = BigDecimal.ZERO;
        BigDecimal labor = BigDecimal.ZERO;
        for (ServiceItem item : ticket.getItems()) {
            if (item.getItemType() == ServiceItem.ItemType.part
                    || item.getItemType() == ServiceItem.ItemType.consumable) {
                parts = parts.add(item.getLineTotal());
            } else if (item.getItemType() == ServiceItem.ItemType.labor) {
                labor = labor.add(item.getLineTotal());
            }
        }
        ticket.setTotalParts(parts);
        ticket.setTotalLabor(labor);
        ticket.setTotalCost(parts.add(labor));
    }

    private void validateTransition(ServiceTicket.Status current, ServiceTicket.Status next) {
        boolean valid = switch (current) {
            case received -> next == ServiceTicket.Status.diagnosed || next == ServiceTicket.Status.cancelled;
            case diagnosed -> next == ServiceTicket.Status.in_progress || next == ServiceTicket.Status.cancelled;
            case in_progress -> next == ServiceTicket.Status.waiting_parts
                    || next == ServiceTicket.Status.completed || next == ServiceTicket.Status.cancelled;
            case waiting_parts -> next == ServiceTicket.Status.in_progress || next == ServiceTicket.Status.cancelled;
            case completed -> next == ServiceTicket.Status.delivered;
            default -> false;
        };
        if (!valid) {
            throw new BusinessRuleException("Invalid ticket status transition: " + current + " → " + next);
        }
    }

    private ServiceTicket getTicket(Long id, AuthenticatedUser actor) {
        ServiceTicket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Service ticket not found: " + id));
        if (!actor.isSuperAdmin() && !ticket.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Service ticket not found: " + id);
        }
        return ticket;
    }

    private String generateTicketNumber() {
        String prefix = "SVC-" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDateTime.now()) + "-";
        String candidate;
        do {
            candidate = prefix + String.format("%04d", ThreadLocalRandom.current().nextInt(1, 10000));
        } while (ticketRepository.existsByTicketNumber(candidate));
        return candidate;
    }
}
