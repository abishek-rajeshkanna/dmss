package com.hyundai.dms.service;

import com.hyundai.dms.dto.TestDriveRequest;
import com.hyundai.dms.dto.TestDriveResponse;
import com.hyundai.dms.entity.*;
import com.hyundai.dms.exception.BusinessRuleException;
import com.hyundai.dms.exception.InvalidStatusTransitionException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.*;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class TestDriveService {

    private final TestDriveRepository testDriveRepository;
    private final CustomerRepository customerRepository;
    private final InventoryRepository inventoryRepository;
    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final NotificationService notificationService;

    @Transactional(readOnly = true)
    public Page<TestDriveResponse> findAll(TestDrive.Status status, Long customerId,
                                           Long inventoryId, AuthenticatedUser actor, Pageable pageable) {
        Long dealershipId = actor.isSuperAdmin() ? null : actor.getDealershipId();
        if (dealershipId == null) {
            return testDriveRepository.findAll(pageable).map(TestDriveResponse::from);
        }
        return testDriveRepository.findByFilters(dealershipId, status, customerId, inventoryId, pageable)
                .map(TestDriveResponse::from);
    }

    @Transactional
    public TestDriveResponse schedule(TestDriveRequest req, AuthenticatedUser actor) {
        Inventory inv = inventoryRepository.findById(req.inventoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found"));

        if (inv.getStatus() != Inventory.Status.available && inv.getStatus() != Inventory.Status.test_drive) {
            throw new BusinessRuleException("Vehicle is not available for test drive");
        }

        Customer customer = customerRepository.findById(req.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
        User staff = userRepository.findById(req.staffId())
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found"));
        Dealership dealership = dealershipRepository.findById(actor.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        TestDrive td = new TestDrive();
        td.setDealership(dealership);
        td.setCustomer(customer);
        td.setInventory(inv);
        td.setStaff(staff);
        td.setScheduledAt(req.scheduledAt());
        td.setOdometerBefore(req.odometerBefore());
        td.setNotes(req.notes());
        td = testDriveRepository.save(td);

        notificationService.createForUser(staff.getId(), "TEST_DRIVE_SCHEDULED",
                "Test drive scheduled",
                "Test drive scheduled for " + customer.getFirstName() + " on " + req.scheduledAt(),
                "test_drives", td.getId());

        return TestDriveResponse.from(td);
    }

    @Transactional
    public void changeStatus(Long id, TestDrive.Status newStatus, AuthenticatedUser actor) {
        TestDrive td = getTestDrive(id, actor);
        TestDrive.Status current = td.getStatus();

        boolean valid = switch (current) {
            case scheduled -> newStatus == TestDrive.Status.ongoing
                    || newStatus == TestDrive.Status.cancelled
                    || newStatus == TestDrive.Status.no_show;
            case ongoing -> newStatus == TestDrive.Status.completed;
            default -> false;
        };

        if (!valid) throw new InvalidStatusTransitionException(current.name(), newStatus.name());

        if (newStatus == TestDrive.Status.ongoing) td.setStartedAt(LocalDateTime.now());
        if (newStatus == TestDrive.Status.completed) td.setReturnedAt(LocalDateTime.now());

        td.setStatus(newStatus);
        testDriveRepository.save(td);
    }

    @Caching(evict = @CacheEvict(value = "test_drives", allEntries = true))
    @Transactional
    public TestDriveResponse update(Long id, TestDriveRequest req, AuthenticatedUser actor) {
        TestDrive td = getTestDrive(id, actor);

        td.setCustomer(customerRepository.findById(req.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found")));
        td.setInventory(inventoryRepository.findById(req.inventoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found")));
        td.setStaff(userRepository.findById(req.staffId())
                .orElseThrow(() -> new ResourceNotFoundException("Staff member not found")));

        if (req.status() == TestDrive.Status.ongoing && td.getStartedAt() == null) {
            td.setStartedAt(LocalDateTime.now());
        } else if (req.status() == TestDrive.Status.completed && td.getReturnedAt() == null) {
            td.setReturnedAt(LocalDateTime.now());
        }

        td.setScheduledAt(req.scheduledAt());
        td.setStatus(req.status());
        td.setOdometerBefore(req.odometerBefore());
        td.setNotes(req.notes());

        return TestDriveResponse.from(testDriveRepository.save(td));
    }

    private TestDrive getTestDrive(Long id, AuthenticatedUser actor) {
        TestDrive td = testDriveRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Test drive not found: " + id));
        if (!actor.isSuperAdmin() && !td.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Test drive not found: " + id);
        }
        return td;
    }
}
