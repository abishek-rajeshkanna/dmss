package com.hyundai.dms.service;

import com.hyundai.dms.dto.InventoryRequest;
import com.hyundai.dms.dto.InventoryResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.entity.Inventory;
import com.hyundai.dms.entity.InventoryHistory;
import com.hyundai.dms.exception.DuplicateResourceException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.DealershipRepository;
import com.hyundai.dms.repository.InventoryHistoryRepository;
import com.hyundai.dms.repository.InventoryRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepository inventoryRepository;
    private final InventoryHistoryRepository inventoryHistoryRepository;
    private final DealershipRepository dealershipRepository;
    private final AuditService auditService;

    @Cacheable("inventory")
    @Transactional(readOnly = true)
    public Page<InventoryResponse> findAll(Inventory.Status status, String make, String model,
                                           Inventory.ConditionType conditionType,
                                           Inventory.FuelType fuelType,
                                           BigDecimal minPrice, BigDecimal maxPrice,
                                           AuthenticatedUser actor, Pageable pageable) {
        Long dealershipId = actor.isSuperAdmin() ? null : actor.getDealershipId();
        if (dealershipId == null) {
            return inventoryRepository.findAll(pageable).map(InventoryResponse::from);
        }
        return inventoryRepository.findByFilters(dealershipId, status, make, model,
                conditionType, fuelType, minPrice, maxPrice, pageable).map(InventoryResponse::from);
    }

    @Transactional(readOnly = true)
    public InventoryResponse findById(Long id, AuthenticatedUser actor) {
        Inventory inv = getInventory(id, actor);
        return InventoryResponse.from(inv);
    }

    @Caching(evict = @CacheEvict(value = "inventory", allEntries = true))
    @Transactional
    public InventoryResponse create(InventoryRequest req, AuthenticatedUser actor) {
        if (inventoryRepository.existsByVin(req.vin()))
            throw new DuplicateResourceException("VIN already exists: " + req.vin());

        Inventory inv = new Inventory();
        inv.setDealership(dealershipRepository.findById(actor.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found")));
        mapToEntity(inv, req);
        inv = inventoryRepository.save(inv);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.INSERT, "inventory", inv.getId(), null, null, null, null);
        return InventoryResponse.from(inv);
    }

    @Caching(evict = @CacheEvict(value = "inventory", allEntries = true))
    @Transactional
    public InventoryResponse update(Long id, InventoryRequest req, AuthenticatedUser actor) {
        Inventory inv = getInventory(id, actor);

        if (inventoryRepository.existsByVinAndIdNot(req.vin(), id))
            throw new DuplicateResourceException("VIN already exists: " + req.vin());

        // Track changes for history
        recordHistoryIfChanged(inv, "selling_price",
                inv.getSellingPrice() != null ? inv.getSellingPrice().toString() : null,
                req.sellingPrice() != null ? req.sellingPrice().toString() : null, actor);
        recordHistoryIfChanged(inv, "cost_price",
                inv.getCostPrice() != null ? inv.getCostPrice().toString() : null,
                req.costPrice() != null ? req.costPrice().toString() : null, actor);

        mapToEntity(inv, req);
        inv = inventoryRepository.save(inv);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "inventory", inv.getId(), null, null, null, null);
        return InventoryResponse.from(inv);
    }

    @Caching(evict = @CacheEvict(value = "inventory", allEntries = true))
    @Transactional
    public void changeStatus(Long id, Inventory.Status newStatus, AuthenticatedUser actor) {
        Inventory inv = getInventory(id, actor);
        String oldStatus = inv.getStatus().name();
        inv.setStatus(newStatus);
        inventoryRepository.save(inv);
        recordHistory(inv, "status", oldStatus, newStatus.name(), actor);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "inventory", inv.getId(), null, null, null, null);
    }

    public Inventory getInventoryById(Long id) {
        return inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found: " + id));
    }

    private Inventory getInventory(Long id, AuthenticatedUser actor) {
        Inventory inv = inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found: " + id));
        if (!actor.isSuperAdmin() && !inv.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Inventory not found: " + id);
        }
        return inv;
    }

    private void recordHistoryIfChanged(Inventory inv, String field, String oldVal, String newVal,
                                        AuthenticatedUser actor) {
        if (oldVal != null && !oldVal.equals(newVal)) {
            recordHistory(inv, field, oldVal, newVal, actor);
        }
    }

    private void recordHistory(Inventory inv, String field, String oldVal, String newVal,
                                AuthenticatedUser actor) {
        InventoryHistory h = new InventoryHistory();
        h.setInventory(inv);
        h.setChangedBy(actor.getUserId());
        h.setFieldName(field);
        h.setOldValue(oldVal);
        h.setNewValue(newVal);
        inventoryHistoryRepository.save(h);
    }

    private void mapToEntity(Inventory inv, InventoryRequest req) {
        inv.setVin(req.vin());
        inv.setMake(req.make());
        inv.setModel(req.model());
        inv.setVariant(req.variant());
        inv.setYear(req.year());
        inv.setColor(req.color());
        inv.setFuelType(req.fuelType());
        inv.setTransmission(req.transmission() != null ? req.transmission() : Inventory.Transmission.manual);
        inv.setBodyType(req.bodyType());
        inv.setMileage(req.mileage() != null ? req.mileage() : 0);
        inv.setEngineCc(req.engineCc());
        inv.setSeating(req.seating());
        inv.setConditionType(req.conditionType());
        inv.setStatus(req.status());
        inv.setCostPrice(req.costPrice());
        inv.setSellingPrice(req.sellingPrice());
        inv.setMsrp(req.msrp());
        inv.setLocation(req.location());
        inv.setNotes(req.notes());
    }
}
