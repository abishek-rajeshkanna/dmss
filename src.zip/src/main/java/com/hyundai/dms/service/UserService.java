package com.hyundai.dms.service;

import com.hyundai.dms.dto.ChangePasswordRequest;
import com.hyundai.dms.dto.UserRequest;
import com.hyundai.dms.dto.UserResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.entity.Dealership;
import com.hyundai.dms.entity.User;
import com.hyundai.dms.exception.DuplicateResourceException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.DealershipRepository;
import com.hyundai.dms.repository.UserRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public Page<UserResponse> findAll(AuthenticatedUser actor, Pageable pageable) {
        if (actor.isSuperAdmin()) {
            return userRepository.findAll(pageable).map(UserResponse::from);
        }
        return userRepository.findByDealershipId(actor.getDealershipId(), pageable).map(UserResponse::from);
    }

    @Transactional(readOnly = true)
    public UserResponse findById(Long id, AuthenticatedUser actor) {
        User user = getUser(id);
        assertSameDealership(user, actor);
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse create(UserRequest req, AuthenticatedUser actor) {
        if (userRepository.existsByEmail(req.email()))
            throw new DuplicateResourceException("Email already in use");

        Dealership dealership = dealershipRepository.findById(req.dealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        User user = new User();
        user.setDealership(dealership);
        user.setFirstName(req.firstName());
        user.setLastName(req.lastName());
        user.setEmail(req.email());
        user.setPasswordHash(passwordEncoder.encode(req.password()));
        user.setRole(req.role());
        user.setPhone(req.phone());

        if (req.managerId() != null) {
            user.setManager(userRepository.findById(req.managerId()).orElse(null));
        }

        user = userRepository.save(user);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.INSERT, "users", user.getId(), null, null, null, null);
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse update(Long id, UserRequest req, AuthenticatedUser actor) {
        User user = getUser(id);
        assertSameDealership(user, actor);

        if (userRepository.existsByEmail(req.email()) && !user.getEmail().equals(req.email()))
            throw new DuplicateResourceException("Email already in use");

        user.setFirstName(req.firstName());
        user.setLastName(req.lastName());
        user.setEmail(req.email());
        user.setRole(req.role());
        user.setPhone(req.phone());

        if (req.managerId() != null) {
            user.setManager(userRepository.findById(req.managerId()).orElse(null));
        }

        user = userRepository.save(user);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "users", user.getId(), null, null, null, null);
        return UserResponse.from(user);
    }

    @Transactional
    public void changeStatus(Long id, String status, AuthenticatedUser actor) {
        User user = getUser(id);
        assertSameDealership(user, actor);
        user.setStatus(User.Status.valueOf(status));
        userRepository.save(user);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "users", user.getId(), null, null, null, null);
    }

    @Transactional
    public void changePassword(Long id, ChangePasswordRequest req, AuthenticatedUser actor) {
        User user = getUser(id);
        assertSameDealership(user, actor);
        user.setPasswordHash(passwordEncoder.encode(req.newPassword()));
        user.setPasswordChangedAt(LocalDateTime.now());
        userRepository.save(user);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.PASSWORD_CHANGE, "users", user.getId(), null, null, null, null);
    }

    @Transactional
    public void softDelete(Long id, AuthenticatedUser actor) {
        User user = getUser(id);
        assertSameDealership(user, actor);
        user.setStatus(User.Status.inactive);
        userRepository.save(user);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.DELETE, "users", user.getId(), null, null, null, null);
    }

    private User getUser(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
    }

    private void assertSameDealership(User user, AuthenticatedUser actor) {
        if (!actor.isSuperAdmin() &&
                !user.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("User not found: " + user.getId());
        }
    }
}
