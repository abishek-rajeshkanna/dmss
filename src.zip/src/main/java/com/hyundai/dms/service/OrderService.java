package com.hyundai.dms.service;

import com.hyundai.dms.dto.CreateOrderRequest;
import com.hyundai.dms.dto.OrderItemRequest;
import com.hyundai.dms.dto.OrderResponse;
import com.hyundai.dms.entity.*;
import com.hyundai.dms.exception.BusinessRuleException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.*;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final InventoryService inventoryService;
    private final AuditService auditService;
    private final NotificationService notificationService;
    private final PaymentRepository paymentRepository;

    @Transactional(readOnly = true)
    public Page<OrderResponse> findAll(Order.Status status, Long customerId,
                                       LocalDate fromDate, LocalDate toDate,
                                       AuthenticatedUser actor, Pageable pageable) {
        Long dealershipId = actor.isSuperAdmin() ? null : actor.getDealershipId();
        return orderRepository.findByFilters(dealershipId, status, customerId, fromDate, toDate, pageable)
                .map(OrderResponse::from);
    }

    @Transactional(readOnly = true)
    public OrderResponse findById(Long id, AuthenticatedUser actor) {
        return OrderResponse.from(getOrder(id, actor));
    }

    @Transactional
    public OrderResponse create(CreateOrderRequest req, AuthenticatedUser actor) {
        Dealership dealership = dealershipRepository.findById(actor.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));
        Customer customer = customerRepository.findById(req.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
        User salesperson = userRepository.findById(actor.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Order order = new Order();
        order.setDealership(dealership);
        order.setCustomer(customer);
        order.setSalesperson(salesperson);
        order.setOrderNumber(generateOrderNumber());
        order.setDeliveryDate(req.deliveryDate());
        order.setDiscountAmount(req.discountAmount() != null ? req.discountAmount() : BigDecimal.ZERO);
        order.setTaxRate(req.taxRate() != null ? req.taxRate() : new BigDecimal("18.00"));
        order.setTradeInValue(req.tradeInValue() != null ? req.tradeInValue() : BigDecimal.ZERO);
        order.setFinancingAmount(req.financingAmount() != null ? req.financingAmount() : BigDecimal.ZERO);
        order.setFinancingTerm(req.financingTerm());
        order.setInterestRate(req.interestRate());
        order.setNotes(req.notes());

        if (req.managerId() != null) {
            order.setManager(userRepository.findById(req.managerId())
                    .orElseThrow(() -> new ResourceNotFoundException("Manager not found")));
        }

        // Build items and reserve vehicle
        for (OrderItemRequest itemReq : req.items()) {
            OrderItem item = buildItem(order, itemReq);
            order.getItems().add(item);
            if (itemReq.inventoryId() != null && item.getItemType() == OrderItem.ItemType.vehicle) {
                Inventory inv = inventoryService.getInventoryById(itemReq.inventoryId());
                if (inv.getStatus() != Inventory.Status.available) {
                    throw new BusinessRuleException("Vehicle " + inv.getVin() + " is not available");
                }
                inventoryService.changeStatus(inv.getId(), Inventory.Status.reserved, actor);
            }
        }

        computeTotals(order);
        final Order savedOrder = orderRepository.save(order);

        // Auto-create pending payment record
        Payment payment = new Payment();
        payment.setOrder(savedOrder);
        payment.setAmount(savedOrder.getTotalAmount());
        payment.setStatus(Payment.Status.pending);
        payment.setMethod(Payment.Method.bank_transfer);
        payment.setRecordedBy(savedOrder.getSalesperson());
        paymentRepository.save(payment);

        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.INSERT, "orders", savedOrder.getId(), null, null, null, null);
        return OrderResponse.from(savedOrder);
    }

    @Transactional
    public OrderResponse update(Long id, CreateOrderRequest req, AuthenticatedUser actor) {
        Order order = getOrder(id, actor);
        // Removed draft-only restriction to allow status updates for all orders
        
        Customer customer = customerRepository.findById(req.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
        order.setCustomer(customer);
        order.setDeliveryDate(req.deliveryDate());
        order.setDiscountAmount(req.discountAmount() != null ? req.discountAmount() : BigDecimal.ZERO);
        order.setTaxRate(req.taxRate() != null ? req.taxRate() : new BigDecimal("18.00"));
        order.setTradeInValue(req.tradeInValue() != null ? req.tradeInValue() : BigDecimal.ZERO);
        order.setFinancingAmount(req.financingAmount() != null ? req.financingAmount() : BigDecimal.ZERO);
        order.setFinancingTerm(req.financingTerm());
        order.setInterestRate(req.interestRate());
        order.setNotes(req.notes());
        if (req.status() != null) {
            order.setStatus(req.status());
        }

        if (req.managerId() != null) {
            order.setManager(userRepository.findById(req.managerId())
                    .orElseThrow(() -> new ResourceNotFoundException("Manager not found")));
        }

        order.getItems().clear();
        for (OrderItemRequest itemReq : req.items()) {
            order.getItems().add(buildItem(order, itemReq));
        }

        computeTotals(order);
        order = orderRepository.save(order);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "orders", order.getId(), null, null, null, null);
        return OrderResponse.from(order);
    }

    @Transactional
    public OrderResponse changeStatus(Long id, Order.Status newStatus, String cancellationReason,
                                      AuthenticatedUser actor) {
        Order order = getOrder(id, actor);
        validateTransition(order.getStatus(), newStatus);

        if (newStatus == Order.Status.delivered) {
            order.setDeliveryDate(LocalDate.now());
            // Mark vehicle as sold
            order.getItems().stream()
                    .filter(i -> i.getItemType() == OrderItem.ItemType.vehicle && i.getInventory() != null)
                    .forEach(i -> inventoryService.changeStatus(i.getInventory().getId(),
                            Inventory.Status.sold, actor));
        } else if (newStatus == Order.Status.cancelled) {
            order.setCancellationReason(cancellationReason);
            // Release reserved vehicle back to available
            order.getItems().stream()
                    .filter(i -> i.getItemType() == OrderItem.ItemType.vehicle && i.getInventory() != null)
                    .forEach(i -> {
                        Inventory inv = i.getInventory();
                        if (inv.getStatus() == Inventory.Status.reserved) {
                            inventoryService.changeStatus(inv.getId(), Inventory.Status.available, actor);
                        }
                    });
        } else if (newStatus == Order.Status.confirmed && order.getManager() != null) {
            notificationService.createForUser(order.getManager().getId(), "ORDER_CONFIRMED",
                    "Order Confirmed", "Order " + order.getOrderNumber() + " has been confirmed.",
                    "orders", order.getId());
        }

        order.setStatus(newStatus);
        order = orderRepository.save(order);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "orders", order.getId(), null, null, null, null);
        return OrderResponse.from(order);
    }

    // Package-visible for unit tests
    void computeTotals(Order order) {
        BigDecimal subtotal = order.getItems().stream()
                .map(OrderItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal taxAmount = subtotal
                .multiply(order.getTaxRate())
                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
        BigDecimal total = subtotal.add(taxAmount).subtract(order.getDiscountAmount());

        order.setSubtotal(subtotal);
        order.setTaxAmount(taxAmount);
        order.setTotalAmount(total.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : total);
    }

    private OrderItem buildItem(Order order, OrderItemRequest req) {
        OrderItem item = new OrderItem();
        item.setOrder(order);
        item.setItemType(req.itemType());
        item.setDescription(req.description());
        item.setUnitPrice(req.unitPrice());
        item.setQuantity(req.quantity());
        item.setDiscount(req.discount() != null ? req.discount() : BigDecimal.ZERO);
        if (req.inventoryId() != null) {
            item.setInventory(inventoryService.getInventoryById(req.inventoryId()));
        }
        BigDecimal lineTotal = req.unitPrice()
                .multiply(BigDecimal.valueOf(req.quantity()))
                .subtract(item.getDiscount());
        item.setLineTotal(lineTotal.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : lineTotal);
        return item;
    }

    private void validateTransition(Order.Status current, Order.Status next) {
        if (current == next) return;
        
        // Allow all transitions for now to ensure maximum editability as requested
        boolean valid = true; 
        
        if (!valid) {
            throw new BusinessRuleException("Invalid order status transition: " + current + " → " + next);
        }
    }

    private Order getOrder(Long id, AuthenticatedUser actor) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + id));
        if (!actor.isSuperAdmin() && !order.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Order not found: " + id);
        }
        return order;
    }

    private String generateOrderNumber() {
        String prefix = "ORD-" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now()) + "-";
        String candidate;
        do {
            candidate = prefix + String.format("%04d", ThreadLocalRandom.current().nextInt(1, 10000));
        } while (orderRepository.existsByOrderNumber(candidate));
        return candidate;
    }
}
