package com.hyundai.dms.service;

import com.hyundai.dms.dto.DashboardStatsResponse;
import com.hyundai.dms.entity.Order;
import com.hyundai.dms.entity.ServiceTicket;
import com.hyundai.dms.repository.CustomerRepository;
import com.hyundai.dms.repository.InventoryRepository;
import com.hyundai.dms.repository.OrderRepository;
import com.hyundai.dms.repository.ServiceTicketRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final InventoryRepository inventoryRepository;
    private final CustomerRepository customerRepository;
    private final OrderRepository orderRepository;
    private final ServiceTicketRepository serviceTicketRepository;

    @Transactional(readOnly = true)
    public DashboardStatsResponse getStats(AuthenticatedUser actor) {
        Long dealershipId = actor.isSuperAdmin() ? null : actor.getDealershipId();

        long inventoryCount = (dealershipId == null) 
                ? inventoryRepository.count() 
                : inventoryRepository.countByDealershipId(dealershipId);

        long customerCount = (dealershipId == null) 
                ? customerRepository.count() 
                : customerRepository.countByDealershipId(dealershipId);

        long pendingOrders = (dealershipId == null)
                ? orderRepository.countByStatus(Order.Status.draft)
                : orderRepository.countByDealershipIdAndStatus(dealershipId, Order.Status.draft);

        long activeTickets = (dealershipId == null)
                ? serviceTicketRepository.countByStatusIn(
                    java.util.List.of(ServiceTicket.Status.received, ServiceTicket.Status.diagnosed, ServiceTicket.Status.in_progress))
                : serviceTicketRepository.countByDealershipIdAndStatusIn(dealershipId, 
                    java.util.List.of(ServiceTicket.Status.received, ServiceTicket.Status.diagnosed, ServiceTicket.Status.in_progress));

        // Today's Sales Calculation
        LocalDateTime startOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        LocalDateTime endOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        
        BigDecimal todaySales = (dealershipId == null)
                ? orderRepository.sumTotalAmountByOrderDateBetween(startOfDay, endOfDay)
                : orderRepository.sumTotalAmountByDealershipIdAndOrderDateBetween(dealershipId, startOfDay, endOfDay);

        return new DashboardStatsResponse(
                inventoryCount,
                customerCount,
                pendingOrders,
                activeTickets,
                todaySales != null ? todaySales : BigDecimal.ZERO
        );
    }
}
