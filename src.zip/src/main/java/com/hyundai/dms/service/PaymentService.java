package com.hyundai.dms.service;

import com.hyundai.dms.dto.PaymentRequest;
import com.hyundai.dms.dto.PaymentResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.entity.Order;
import com.hyundai.dms.entity.Payment;
import com.hyundai.dms.entity.User;
import com.hyundai.dms.exception.BusinessRuleException;
import com.hyundai.dms.exception.OrderAlreadyPaidException;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.OrderRepository;
import com.hyundai.dms.repository.PaymentRepository;
import com.hyundai.dms.repository.UserRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public Page<PaymentResponse> findAll(Long orderId, Payment.Status status,
                                         AuthenticatedUser actor, Pageable pageable) {
        if (orderId != null) {
            return paymentRepository.findByOrderId(orderId, pageable).map(PaymentResponse::from);
        }
        if (status != null) {
            return paymentRepository.findByStatus(status, pageable).map(PaymentResponse::from);
        }
        return paymentRepository.findAll(pageable).map(PaymentResponse::from);
    }

    @Transactional
    public PaymentResponse record(PaymentRequest req, AuthenticatedUser actor) {
        Order order = orderRepository.findById(req.orderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + req.orderId()));

        if (!actor.isSuperAdmin() && !order.getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Order not found: " + req.orderId());
        }

        // Overpayment check
        BigDecimal alreadyPaid = paymentRepository.sumCompletedByOrderId(order.getId());
        if (alreadyPaid.add(req.amount()).compareTo(order.getTotalAmount()) > 0) {
            throw new OrderAlreadyPaidException(
                    "Payment would exceed order total. Already paid: " + alreadyPaid
                    + ", order total: " + order.getTotalAmount());
        }

        User recorder = userRepository.findById(actor.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setRecordedBy(recorder);
        payment.setAmount(req.amount());
        payment.setMethod(req.method());
        payment.setTransactionRef(req.transactionRef());
        payment.setGateway(req.gateway());
        payment.setPaidAt(req.paidAt() != null ? req.paidAt() : LocalDateTime.now());
        payment.setNotes(req.notes());
        payment.setStatus(Payment.Status.pending);

        payment = paymentRepository.save(payment);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.INSERT, "payments", payment.getId(), null, null, null, null);
        return PaymentResponse.from(payment);
    }

    @Transactional
    public PaymentResponse changeStatus(Long id, Payment.Status newStatus, AuthenticatedUser actor) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id));

        if (!actor.isSuperAdmin() &&
                !payment.getOrder().getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Payment not found: " + id);
        }

        validatePaymentTransition(payment.getStatus(), newStatus);

        if (newStatus == Payment.Status.completed && payment.getPaidAt() == null) {
            payment.setPaidAt(LocalDateTime.now());
        }
        payment.setStatus(newStatus);
        payment = paymentRepository.save(payment);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "payments", payment.getId(), null, null, null, null);
        return PaymentResponse.from(payment);
    }

    @Transactional
    public PaymentResponse update(Long id, PaymentRequest req, AuthenticatedUser actor) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id));

        if (!actor.isSuperAdmin() &&
                !payment.getOrder().getDealership().getId().equals(actor.getDealershipId())) {
            throw new ResourceNotFoundException("Payment not found: " + id);
        }

        payment.setAmount(req.amount());
        payment.setMethod(req.method());
        payment.setStatus(req.status() != null ? req.status() : payment.getStatus());
        payment.setTransactionRef(req.transactionRef());
        payment.setGateway(req.gateway());
        payment.setNotes(req.notes());
        if (req.paidAt() != null) payment.setPaidAt(req.paidAt());

        payment = paymentRepository.save(payment);
        auditService.log(actor.getUserId(), actor.getDealershipId(),
                AuditLog.Action.UPDATE, "payments", payment.getId(), null, null, null, null);
        return PaymentResponse.from(payment);
    }

    private void validatePaymentTransition(Payment.Status current, Payment.Status next) {
        boolean valid = switch (current) {
            case pending -> next == Payment.Status.completed || next == Payment.Status.failed;
            case completed -> next == Payment.Status.refunded;
            default -> false;
        };
        if (!valid) {
            throw new BusinessRuleException("Invalid payment status transition: " + current + " → " + next);
        }
    }
}
