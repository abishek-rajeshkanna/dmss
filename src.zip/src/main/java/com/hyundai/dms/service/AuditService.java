package com.hyundai.dms.service;

import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final AuditLogRepository auditLogRepository;

    @Async
    public void log(Long userId, Long dealershipId, AuditLog.Action action,
                    String tableName, Long recordId,
                    String oldValues, String newValues,
                    String ipAddress, String userAgent) {
        try {
            AuditLog entry = new AuditLog();
            entry.setUserId(userId != null ? userId.intValue() : null);
            entry.setDealershipId(dealershipId != null ? dealershipId.intValue() : null);
            entry.setAction(action);
            entry.setTableName(tableName);
            entry.setRecordId(recordId != null ? recordId.intValue() : null);
            entry.setOldValues(oldValues);
            entry.setNewValues(newValues);
            entry.setIpAddress(ipAddress);
            entry.setUserAgent(userAgent);
            auditLogRepository.save(entry);
            log.info("Audit: action={}, table={}, recordId={}", action, tableName, recordId);
        } catch (Exception e) {
            log.error("Failed to write audit log: action={}, table={}", action, tableName, e);
        }
    }
}