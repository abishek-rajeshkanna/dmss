package com.hyundai.dms.service;

import com.hyundai.dms.entity.Notification;
import com.hyundai.dms.entity.User;
import com.hyundai.dms.exception.ResourceNotFoundException;
import com.hyundai.dms.repository.NotificationRepository;
import com.hyundai.dms.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    public void createForUser(Long userId, String type, String title, String body,
                              String refType, Long refId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) return;

        Notification n = new Notification();
        n.setUser(user);
        n.setType(type);
        n.setTitle(title);
        n.setBody(body);
        n.setReferenceType(refType);
        n.setReferenceId(refId);
        notificationRepository.save(n);
    }

    @Transactional(readOnly = true)
    public Page<Notification> getForUser(Long userId, Pageable pageable) {
        return notificationRepository.findByUserIdOrderByIsReadAscCreatedAtDesc(userId, pageable);
    }

    @Transactional
    public void markRead(Long notificationId, Long userId) {
        Notification n = notificationRepository.findByIdAndUserId(notificationId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        n.setRead(true);
        n.setReadAt(LocalDateTime.now());
        notificationRepository.save(n);
    }

    @Transactional
    public void markAllRead(Long userId) {
        notificationRepository.markAllReadByUserId(userId, LocalDateTime.now());
    }
}
