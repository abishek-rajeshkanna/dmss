package com.hyundai.dms.util;

import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.exception.BusinessRuleException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.util.Set;

public final class PaginationUtil {

    private PaginationUtil() {}

    public static final int MAX_PAGE_SIZE = 100;

    /**
     * Build a PageRequest, validating the sort field against an allowed set.
     * Throws BusinessRuleException (→ 400) if the sort field is not allowed.
     */
    public static PageRequest buildPageRequest(int page, int size, String sort, String dir,
                                               Set<String> allowedSortFields) {
        if (size > MAX_PAGE_SIZE) size = MAX_PAGE_SIZE;
        if (size < 1) size = 1;
        if (page < 0) page = 0;

        if (sort != null && !allowedSortFields.isEmpty() && !allowedSortFields.contains(sort)) {
            throw new BusinessRuleException(
                    "Invalid sort field '" + sort + "'. Allowed: " + allowedSortFields);
        }

        Sort.Direction direction = "asc".equalsIgnoreCase(dir) ? Sort.Direction.ASC : Sort.Direction.DESC;
        String sortField = (sort != null && !sort.isBlank()) ? sort : allowedSortFields.iterator().next();
        return PageRequest.of(page, size, Sort.by(direction, sortField));
    }

    /** Convenience overload — no sort field validation. */
    public static PageRequest buildPageRequest(int page, int size, String sort, String dir) {
        return buildPageRequest(page, size, sort, dir, Set.of());
    }

    public static <T> PaginatedResponse<T> toResponse(Page<T> pageResult) {
        return PaginatedResponse.of(pageResult);
    }
}
