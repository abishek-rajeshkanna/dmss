package com.hyundai.dms.controller;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.stats.CacheStats;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final CacheManager cacheManager;

    @GetMapping("/cache/stats")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public Map<String, Object> cacheStats() {
        Map<String, Object> result = new LinkedHashMap<>();
        for (String name : cacheManager.getCacheNames()) {
            org.springframework.cache.Cache springCache = cacheManager.getCache(name);
            if (springCache instanceof CaffeineCache caffeineCache) {
                Cache<Object, Object> nativeCache = caffeineCache.getNativeCache();
                CacheStats stats = nativeCache.stats();
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("size", nativeCache.estimatedSize());
                entry.put("hitCount", stats.hitCount());
                entry.put("missCount", stats.missCount());
                entry.put("hitRate", stats.hitRate());
                entry.put("evictionCount", stats.evictionCount());
                result.put(name, entry);
            }
        }
        return result;
    }
}
