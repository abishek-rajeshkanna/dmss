package com.hyundai.dms.controller;

import com.hyundai.dms.dto.*;
import com.hyundai.dms.entity.Inventory;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.InventoryService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Set;

@RestController
@RequestMapping("/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "make", "model", "year", "sellingPrice", "status", "createdAt");

    @GetMapping
    public ResponseEntity<PaginatedResponse<InventoryResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) Inventory.Status status,
            @RequestParam(required = false) String make,
            @RequestParam(required = false) String model,
            @RequestParam(required = false) Inventory.ConditionType conditionType,
            @RequestParam(required = false) Inventory.FuelType fuelType,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @AuthenticationPrincipal AuthenticatedUser user) {
        PageRequest pageable = PaginationUtil.buildPageRequest(page, size, sort, direction, ALLOWED_SORT);
        return ResponseEntity.ok(PaginatedResponse.from(
                inventoryService.findAll(status, make, model, conditionType, fuelType,
                        minPrice, maxPrice, user, pageable)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<InventoryResponse> getById(@PathVariable Long id,
                                                     @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(inventoryService.findById(id, user));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<InventoryResponse> create(@Valid @RequestBody InventoryRequest request,
                                                    @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(inventoryService.create(request, user));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<InventoryResponse> update(@PathVariable Long id,
                                                    @Valid @RequestBody InventoryRequest request,
                                                    @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(inventoryService.update(id, request, user));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> changeStatus(@PathVariable Long id,
                                             @RequestParam Inventory.Status status,
                                             @AuthenticationPrincipal AuthenticatedUser user) {
        inventoryService.changeStatus(id, status, user);
        return ResponseEntity.noContent().build();
    }
}
