package com.hyundai.dms.controller;

import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.entity.AuditLog;
import com.hyundai.dms.repository.AuditLogRepository;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.util.PaginationUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/audit-logs")
@RequiredArgsConstructor
public class AuditLogController {

    private final AuditLogRepository auditLogRepository;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "action", "tableName", "createdAt");

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public PaginatedResponse<AuditLog> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String dir,
            @AuthenticationPrincipal AuthenticatedUser actor) {
        Page<AuditLog> result = actor.isSuperAdmin()
                ? auditLogRepository.findAll(PaginationUtil.buildPageRequest(page, size, sort, dir, ALLOWED_SORT))
                : auditLogRepository.findByDealershipId(actor.getDealershipId(),
                        PaginationUtil.buildPageRequest(page, size, sort, dir, ALLOWED_SORT));
        return PaginatedResponse.of(result);
    }
}
