package com.hyundai.dms.controller;

import com.hyundai.dms.dto.*;
import com.hyundai.dms.entity.TestDrive;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.TestDriveService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/test-drives")
@RequiredArgsConstructor
public class TestDriveController {

    private final TestDriveService testDriveService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "scheduledAt", "status", "createdAt");

    @GetMapping
    public ResponseEntity<PaginatedResponse<TestDriveResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "scheduledAt") String sort,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) TestDrive.Status status,
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) Long inventoryId,
            @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(PaginatedResponse.from(
                testDriveService.findAll(status, customerId, inventoryId, user,
                        PaginationUtil.buildPageRequest(page, size, sort, direction, ALLOWED_SORT))));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('RECEPTIONIST','SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<TestDriveResponse> schedule(@Valid @RequestBody TestDriveRequest request,
                                                      @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(testDriveService.schedule(request, user));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('RECEPTIONIST','SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> changeStatus(@PathVariable Long id,
                                             @RequestParam TestDrive.Status status,
                                             @AuthenticationPrincipal AuthenticatedUser user) {
        testDriveService.changeStatus(id, status, user);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<TestDriveResponse> update(@PathVariable Long id,
                                                    @Valid @RequestBody TestDriveRequest request,
                                                    @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(testDriveService.update(id, request, user));
    }
}
