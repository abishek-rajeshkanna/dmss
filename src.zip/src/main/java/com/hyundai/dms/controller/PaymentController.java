package com.hyundai.dms.controller;

import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.dto.PaymentRequest;
import com.hyundai.dms.dto.PaymentResponse;
import com.hyundai.dms.dto.StatusRequest;
import com.hyundai.dms.entity.Payment;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.PaymentService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "amount", "status", "paidAt", "createdAt");

    @GetMapping
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public PaginatedResponse<PaymentResponse> list(
            @RequestParam(required = false) Long orderId,
            @RequestParam(required = false) Payment.Status status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal AuthenticatedUser actor) {
        return PaginatedResponse.of(paymentService.findAll(orderId, status, actor,
                PaginationUtil.buildPageRequest(page, size, "createdAt", "desc", ALLOWED_SORT)));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public PaymentResponse record(@Valid @RequestBody PaymentRequest req,
                                  @AuthenticationPrincipal AuthenticatedUser actor) {
        return paymentService.record(req, actor);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public PaymentResponse changeStatus(@PathVariable Long id,
                                        @RequestBody StatusRequest req,
                                        @AuthenticationPrincipal AuthenticatedUser actor) {
        return paymentService.changeStatus(id, Payment.Status.valueOf(req.status()), actor);
    }
}
