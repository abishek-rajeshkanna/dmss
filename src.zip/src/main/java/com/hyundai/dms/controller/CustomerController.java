package com.hyundai.dms.controller;

import com.hyundai.dms.dto.*;
import com.hyundai.dms.entity.Customer;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.CustomerService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "firstName", "lastName", "email", "status", "createdAt");

    @GetMapping
    public ResponseEntity<PaginatedResponse<CustomerResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) Customer.Status status,
            @RequestParam(required = false) Long assignedTo,
            @AuthenticationPrincipal AuthenticatedUser user) {
        PageRequest pageable = PaginationUtil.buildPageRequest(page, size, sort, direction, ALLOWED_SORT);
        return ResponseEntity.ok(PaginatedResponse.from(
                customerService.findAll(status, assignedTo, user, pageable)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerResponse> getById(@PathVariable Long id,
                                                    @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(customerService.findById(id, user));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SALESPERSON','RECEPTIONIST','MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<CustomerResponse> create(@Valid @RequestBody CustomerRequest request,
                                                   @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(customerService.create(request, user));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<CustomerResponse> update(@PathVariable Long id,
                                                   @Valid @RequestBody CustomerRequest request,
                                                   @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(customerService.update(id, request, user));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> changeStatus(@PathVariable Long id,
                                             @Valid @RequestBody StatusRequest request,
                                             @AuthenticationPrincipal AuthenticatedUser user) {
        customerService.changeStatus(id, request.status(), user);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                       @AuthenticationPrincipal AuthenticatedUser user) {
        customerService.softDelete(id, user);
        return ResponseEntity.noContent().build();
    }
}
