package com.hyundai.dms.controller;

import com.hyundai.dms.dto.DealershipRequest;
import com.hyundai.dms.dto.DealershipResponse;
import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.DealershipService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/dealerships")
@RequiredArgsConstructor
public class DealershipController {

    private final DealershipService dealershipService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "name", "city", "status", "createdAt");

    @GetMapping
    public ResponseEntity<PaginatedResponse<DealershipResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "asc") String direction) {
        PageRequest pageable = PaginationUtil.buildPageRequest(page, size, sort, direction, ALLOWED_SORT);
        return ResponseEntity.ok(PaginatedResponse.from(dealershipService.findAll(pageable)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<DealershipResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(dealershipService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public ResponseEntity<DealershipResponse> create(@Valid @RequestBody DealershipRequest request,
                                                     @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(dealershipService.create(request, user));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public ResponseEntity<DealershipResponse> update(@PathVariable Long id,
                                                     @Valid @RequestBody DealershipRequest request,
                                                     @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(dealershipService.update(id, request, user));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                       @AuthenticationPrincipal AuthenticatedUser user) {
        dealershipService.softDelete(id, user);
        return ResponseEntity.noContent().build();
    }
}
