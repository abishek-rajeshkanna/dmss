package com.hyundai.dms.controller;

import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.dto.ServiceItemRequest;
import com.hyundai.dms.dto.ServiceTicketRequest;
import com.hyundai.dms.dto.ServiceTicketResponse;
import com.hyundai.dms.dto.StatusRequest;
import com.hyundai.dms.entity.ServiceTicket;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.ServiceTicketService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/service-tickets")
@RequiredArgsConstructor
public class ServiceTicketController {

    private final ServiceTicketService serviceTicketService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "ticketNumber", "priority", "status", "dropOffAt", "createdAt");

    @GetMapping
    @PreAuthorize("hasAnyRole('TECHNICIAN','SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public PaginatedResponse<ServiceTicketResponse> list(
            @RequestParam(required = false) ServiceTicket.Status status,
            @RequestParam(required = false) ServiceTicket.Priority priority,
            @RequestParam(required = false) Long assignedTo,
            @RequestParam(required = false) Long customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String dir,
            @AuthenticationPrincipal AuthenticatedUser actor) {
        return PaginatedResponse.of(serviceTicketService.findAll(status, priority, assignedTo, customerId,
                actor, PaginationUtil.buildPageRequest(page, size, sort, dir, ALLOWED_SORT)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('TECHNICIAN','SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ServiceTicketResponse getById(@PathVariable Long id,
                                         @AuthenticationPrincipal AuthenticatedUser actor) {
        return serviceTicketService.findById(id, actor);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ServiceTicketResponse create(@Valid @RequestBody ServiceTicketRequest req,
                                        @AuthenticationPrincipal AuthenticatedUser actor) {
        return serviceTicketService.create(req, actor);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public ServiceTicketResponse update(@PathVariable Long id,
                                        @Valid @RequestBody ServiceTicketRequest req,
                                        @AuthenticationPrincipal AuthenticatedUser actor) {
        return serviceTicketService.update(id, req, actor);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('TECHNICIAN','MANAGER','ADMIN','SUPER_ADMIN')")
    public ServiceTicketResponse changeStatus(@PathVariable Long id,
                                              @RequestBody StatusRequest req,
                                              @AuthenticationPrincipal AuthenticatedUser actor) {
        ServiceTicket.Status newStatus = ServiceTicket.Status.valueOf(req.status());
        return serviceTicketService.changeStatus(id, newStatus, null, null, actor);
    }

    @PostMapping("/{id}/items")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('TECHNICIAN','MANAGER','ADMIN','SUPER_ADMIN')")
    public ServiceTicketResponse addItem(@PathVariable Long id,
                                         @Valid @RequestBody ServiceItemRequest req,
                                         @AuthenticationPrincipal AuthenticatedUser actor) {
        return serviceTicketService.addItem(id, req, actor);
    }
}
