package com.hyundai.dms.controller;

import com.hyundai.dms.dto.CreateOrderRequest;
import com.hyundai.dms.dto.OrderResponse;
import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.dto.StatusRequest;
import com.hyundai.dms.entity.Order;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.OrderService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Set;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "orderNumber", "orderDate", "totalAmount", "status", "createdAt");

    @GetMapping
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public PaginatedResponse<OrderResponse> list(
            @RequestParam(required = false) Order.Status status,
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "orderDate") String sort,
            @RequestParam(defaultValue = "desc") String dir,
            @AuthenticationPrincipal AuthenticatedUser actor) {
        Page<OrderResponse> result = orderService.findAll(status, customerId, fromDate, toDate, actor,
                PaginationUtil.buildPageRequest(page, size, sort, dir, ALLOWED_SORT));
        return PaginatedResponse.of(result);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public OrderResponse getById(@PathVariable Long id,
                                 @AuthenticationPrincipal AuthenticatedUser actor) {
        return orderService.findById(id, actor);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public OrderResponse create(@Valid @RequestBody CreateOrderRequest req,
                                @AuthenticationPrincipal AuthenticatedUser actor) {
        return orderService.create(req, actor);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SALESPERSON','MANAGER','ADMIN','SUPER_ADMIN')")
    public OrderResponse update(@PathVariable Long id,
                                @Valid @RequestBody CreateOrderRequest req,
                                @AuthenticationPrincipal AuthenticatedUser actor) {
        return orderService.update(id, req, actor);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public OrderResponse changeStatus(@PathVariable Long id,
                                      @RequestBody StatusRequest req,
                                      @AuthenticationPrincipal AuthenticatedUser actor) {
        Order.Status newStatus = Order.Status.valueOf(req.status());
        return orderService.changeStatus(id, newStatus, req.reason(), actor);
    }
}
