package com.hyundai.dms.controller;

import com.hyundai.dms.dto.PaginatedResponse;
import com.hyundai.dms.entity.Notification;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    public PaginatedResponse<Notification> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal AuthenticatedUser actor) {
        return PaginatedResponse.of(
                notificationService.getForUser(actor.getUserId(),
                        PageRequest.of(page, Math.min(size, 100))));
    }

    @PatchMapping("/{id}/read")
    public void markRead(@PathVariable Long id,
                         @AuthenticationPrincipal AuthenticatedUser actor) {
        notificationService.markRead(id, actor.getUserId());
    }

    @PatchMapping("/read-all")
    public void markAllRead(@AuthenticationPrincipal AuthenticatedUser actor) {
        notificationService.markAllRead(actor.getUserId());
    }
}
