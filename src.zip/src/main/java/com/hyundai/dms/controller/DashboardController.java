package com.hyundai.dms.controller;

import com.hyundai.dms.dto.DashboardStatsResponse;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/stats")
    public DashboardStatsResponse getStats(@AuthenticationPrincipal AuthenticatedUser actor) {
        return dashboardService.getStats(actor);
    }
}
