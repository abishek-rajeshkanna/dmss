package com.hyundai.dms.controller;

import com.hyundai.dms.dto.*;
import com.hyundai.dms.security.AuthenticatedUser;
import com.hyundai.dms.service.UserService;
import com.hyundai.dms.util.PaginationUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    private static final Set<String> ALLOWED_SORT = Set.of("id", "firstName", "lastName", "email", "role", "status", "createdAt");

    @GetMapping
    public ResponseEntity<PaginatedResponse<UserResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "asc") String direction,
            @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(PaginatedResponse.from(userService.findAll(user,
                PaginationUtil.buildPageRequest(page, size, sort, direction, ALLOWED_SORT))));
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getById(@PathVariable Long id,
                                                @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(userService.findById(id, user));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<UserResponse> create(@Valid @RequestBody UserRequest request,
                                               @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.create(request, user));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<UserResponse> update(@PathVariable Long id,
                                               @Valid @RequestBody UserRequest request,
                                               @AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(userService.update(id, request, user));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> changeStatus(@PathVariable Long id,
                                             @Valid @RequestBody StatusRequest request,
                                             @AuthenticationPrincipal AuthenticatedUser user) {
        userService.changeStatus(id, request.status(), user);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/password")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> changePassword(@PathVariable Long id,
                                               @Valid @RequestBody ChangePasswordRequest request,
                                               @AuthenticationPrincipal AuthenticatedUser user) {
        userService.changePassword(id, request, user);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                       @AuthenticationPrincipal AuthenticatedUser user) {
        userService.softDelete(id, user);
        return ResponseEntity.noContent().build();
    }
}
